import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, PhoneCall } from "lucide-react";

const products = [
  {
    name: "Tênis Esportivo Masculino",
    price: "R$ 199,90",
    image: "https://via.placeholder.com/300x200.png?text=T%C3%AAnis+Masculino",
  },
  {
    name: "Sapatilha Feminina Conforto",
    price: "R$ 149,90",
    image: "https://via.placeholder.com/300x200.png?text=Sapatilha+Feminina",
  },
  {
    name: "Bota Casual Unissex",
    price: "R$ 229,90",
    image: "https://via.placeholder.com/300x200.png?text=Bota+Unissex",
  },
];

export default function Stride() {
  return (
    <div className="p-6 bg-gradient-to-br from-zinc-50 to-zinc-200 min-h-screen">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-zinc-800">Stride</h1>
        <p className="text-zinc-600 text-lg">Estilo e conforto em cada passo</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {products.map((product, index) => (
          <Card key={index} className="rounded-2xl shadow-md">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover rounded-t-2xl"
            />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold text-zinc-800">{product.name}</h2>
              <p className="text-zinc-600 mb-4">{product.price}</p>
              <a
                href="https://wa.me/5521968949110?text=Olá%2C+tenho+interesse+em+comprar+um+produto+Stride%21+Pode+me+ajudar%3F"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full gap-2">
                  <ShoppingCart size={18} /> Comprar no WhatsApp
                </Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </section>

      <footer className="mt-16 text-center text-zinc-600 text-sm">
        <p>Entregamos para todo o Brasil 🚚</p>
        <p>Pagamento via Pix: <strong>16050696713</strong></p>
        <p className="mt-2">Stride © {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
}
