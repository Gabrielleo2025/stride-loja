import Stride from "../components/Stride";
export default function Home() {
  return <Stride />;
}
